//
//  main.m
//  PushTest
//
//  Created by 刘小菊 on 17/11/29.
//  Copyright © 2017年 刘小菊. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
